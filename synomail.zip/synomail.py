#!/bin/python
# -*- coding: utf-8 -*-

from synomail.synomail import main

main()
